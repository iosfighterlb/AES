//
//  TwoViewController.m
//  WebAPP
//
//  Created by 刘贵宏 on 2018/8/16.
//  Copyright © 2018年 Coolgeer. All rights reserved.
//

#import "TwoViewController.h"

#import "ChildViewController.h"
#import "NavigationController.h"

@interface TwoViewController ()

@end

@implementation TwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor redColor];
    [button setTitle:@"TwoVC" forState:UIControlStateNormal];
    button.frame = CGRectMake(100, 100, 100, 100);
    [button addTarget:self action:@selector(buttonDidTouched:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    self.view.backgroundColor = [UIColor yellowColor];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)])
    {
        self.edgesForExtendedLayout=UIRectEdgeNone;
    }
    
//    ChildViewController *childVC = [[ChildViewController alloc] init];
//    [self addChildViewController:childVC];
//    [self.view addSubview:childVC.view];
    
//    childVC.view.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
//    [UIViewController attemptRotationToDeviceOrientation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)buttonDidTouched:(UIButton *)button
{
//    [self dismissViewControllerAnimated:YES completion:nil];
    ChildViewController *childVC = [[ChildViewController alloc] init];
    NavigationController *navigation = [[NavigationController alloc] initWithRootViewController:childVC];
    [self presentViewController:navigation animated:YES completion:nil];
}

//- (BOOL)shouldAutorotate
//{
//    if (self.childViewControllers.count > 0) {
//        UIViewController *childViewController = self.childViewControllers.lastObject;
//        return [childViewController shouldAutorotate];
//    }
//    
//    return YES;
//}
//
//- (UIInterfaceOrientationMask)supportedInterfaceOrientations
//{
//    UIInterfaceOrientationMask orientations;
//    orientations = UIInterfaceOrientationMaskPortrait;
//    
//    if (self.childViewControllers.count > 0) {
//        UIViewController *childViewController = self.childViewControllers.lastObject;
//        orientations = [childViewController supportedInterfaceOrientations];
//    }
//    
//    return orientations;
//}
//
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationLandscapeLeft;
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
