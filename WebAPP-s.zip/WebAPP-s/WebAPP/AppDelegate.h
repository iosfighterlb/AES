//
//  AppDelegate.h
//  WebAPP
//
//  Created by apple on 2017/12/15.
//  Copyright © 2017年 Coolgeer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

