//
//  ChildViewController.h
//  WebAPP
//
//  Created by 刘贵宏 on 2018/9/12.
//  Copyright © 2018年 Coolgeer. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ChildViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
