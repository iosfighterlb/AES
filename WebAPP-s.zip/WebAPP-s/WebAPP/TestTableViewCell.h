//
//  TestTableViewCell.h
//  WebAPP
//
//  Created by 刘贵宏 on 2018/9/1.
//  Copyright © 2018年 Coolgeer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestTableViewCell : UITableViewCell

@end
