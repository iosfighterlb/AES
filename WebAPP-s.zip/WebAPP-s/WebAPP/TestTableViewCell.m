//
//  TestTableViewCell.m
//  WebAPP
//
//  Created by 刘贵宏 on 2018/9/1.
//  Copyright © 2018年 Coolgeer. All rights reserved.
//

#import "TestTableViewCell.h"

@implementation TestTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setUpTableViewCell];
    }
    return self;
}

- (void)setUpTableViewCell
{
    
}

@end
