//
//  OneViewController.m
//  WebAPP
//
//  Created by 刘贵宏 on 2018/8/16.
//  Copyright © 2018年 Coolgeer. All rights reserved.
//

#import "OneViewController.h"
#import "TwoViewController.h"

#import "NavigationController.h"

@interface OneViewController ()

@end

@implementation OneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor purpleColor];
    [button setTitle:@"oneVC" forState:UIControlStateNormal];
    button.frame = CGRectMake(100, 100, 100, 100);
    [button addTarget:self action:@selector(buttonDidTouched:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.backgroundColor = [UIColor purpleColor];
    [button2 setTitle:@"Push" forState:UIControlStateNormal];
    button2.frame = CGRectMake(100, 200, 100, 100);
    [button2 addTarget:self action:@selector(button2DidTouched:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    self.view.backgroundColor = [UIColor yellowColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismissVC) name:@"dissmissToOne" object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSLog(@"viewWillAppera");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (void)button2DidTouched:(UIButton *)button
{
    TwoViewController *twoVC = [[TwoViewController alloc] init];
    [self.navigationController pushViewController:twoVC animated:YES];
}

- (void)buttonDidTouched:(UIButton *)button
{
    TwoViewController *twoVC = [[TwoViewController alloc] init];
    NavigationController *navigation = [[NavigationController alloc] initWithRootViewController:twoVC];
    
//    [self presentViewController:navigation animated:YES completion:^{
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            [self.navigationController popViewControllerAnimated:YES];
//        });
//    }];
    

}

- (void)dismissVC
{
    [self.navigationController popViewControllerAnimated:NO];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    });

}

- (BOOL)shouldAutorotate
{
    return NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
