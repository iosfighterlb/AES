//
//  ViewController.m
//  WebAPP
//
//  Created by apple on 2017/12/15.
//  Copyright © 2017年 Coolgeer. All rights reserved.
//

#import "ViewController.h"
#import "NavigationController.h"
#import "OneViewController.h"

@interface ViewController ()<UIWebViewDelegate>

@property (strong, nonatomic) UIWebView *webView;
@property (strong, nonatomic) UIActivityIndicatorView *indicatorView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor purpleColor];
    button.frame = CGRectMake(100, 100, 100, 100);
    [button setTitle:@"rootVC" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonDidTouched:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    self.view.backgroundColor = [UIColor yellowColor];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

}

- (void)buttonDidTouched:(UIButton *)button
{
    OneViewController *twoVC = [[OneViewController alloc] init];
    NavigationController *navi = [[NavigationController alloc] initWithRootViewController:twoVC];
//    [self.navigationController pushViewController:twoVC animated:YES];
    [self presentViewController:navi animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAll;
}

@end
