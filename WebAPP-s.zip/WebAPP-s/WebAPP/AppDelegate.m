//
//  AppDelegate.m
//  WebAPP
//
//  Created by apple on 2017/12/15.
//  Copyright © 2017年 Coolgeer. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

#import "NavigationController.h"

#import "NSData+CommonCrypto.h"
#import "QN_GTM_Base64.h"

#define gIv             @"012345678912345" //自行修改

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    ViewController *rootViewController = [ViewController new];
    rootViewController.view.backgroundColor = [UIColor whiteColor];
    
    NavigationController *navigationController = [[NavigationController alloc] initWithRootViewController:rootViewController];
    self.window.rootViewController = navigationController;
    
    NSData *data = [@"123456" dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *encryString = [self encryptStringForData:data];
    
    NSLog(@"1111 encry : %@", encryString);

    
    NSString *decry = [self decryptStringForData:[QN_GTM_Base64 decodeData:[@"QBZLBWoG8X+PLFfXWbTMhg==" dataUsingEncoding:NSUTF8StringEncoding]]];

    NSLog(@"decry : %@", decry);
    
    [self.window makeKeyAndVisible];
    
    return YES;
}



- (NSString *)encryptStringForData:(NSData *)originData
{
    NSData *keyData = [@"thisisyourkey" dataUsingEncoding:NSUTF8StringEncoding];
    
    CCCryptorStatus status = kCCSuccess;
    
    NSData *encryptData = [originData dataEncryptedUsingAlgorithm:kCCAlgorithmAES128 key:keyData
                                             initializationVector:nil   // ECB加密不会用到iv
                                                          options:(kCCOptionPKCS7Padding)
                                                            error:&status];
    
    
    if (status != kCCSuccess) {
        return nil;
    }
    NSString *encryptString = [QN_GTM_Base64 stringByEncodingData:encryptData];
    
    return encryptString;
}


- (NSString *)decryptStringForData:(NSData *)originData
{
    NSData *keyData = [@"thisisyourkey" dataUsingEncoding:NSUTF8StringEncoding];
    CCCryptorStatus status = kCCSuccess;
    
    NSData *decryptData = [originData decryptedDataUsingAlgorithm:kCCAlgorithmAES128
                                                              key:keyData
                                             initializationVector:nil   // ECB解密不会用到iv CBC的iv，在内置做好了.
                                                          options:(kCCOptionPKCS7Padding)
                                                            error:&status];
    if (status != kCCSuccess) {
        return nil;
    }
    
//    NSString *decryptString = [QN_GTM_Base64 stringByEncodingData:decryptData];   这个不行.
    NSString *decryptString = [[NSString alloc] initWithData:decryptData encoding:NSUTF8StringEncoding];

    return decryptString;
}


@end
